//------------------------------------------------------
namespace SmoothiesApi.Models;
//------------------------------------------------------
public class Smoothie
{
    public int Id { get; set; }
    public required string Title { get; set; }
    public string? Method { get; set; }
    public decimal Rating { get; set; }
}
//------------------------------------------------------

//------------------------------------------------------
using Microsoft.EntityFrameworkCore;
namespace SmoothiesApi.Models;
//------------------------------------------------------
public class SmoothieContext : DbContext
{
    public SmoothieContext(DbContextOptions<SmoothieContext> options)
        : base(options)
    {
    }

    public DbSet<Smoothie> Smoothies { get; set; } = null!;
}
//------------------------------------------------------

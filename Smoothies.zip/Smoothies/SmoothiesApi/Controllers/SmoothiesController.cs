using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmoothiesApi.Models;

namespace SmoothiesApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class SmoothiesController : ControllerBase
    {
        private readonly SmoothieContext _context;

        public SmoothiesController(SmoothieContext context)
        {
            _context = context;
        }

        // GET: host:<port>/smoothies
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Smoothie>>> GetSmoothies()
        {
            return await _context.Smoothies.ToListAsync();
        }

        // GET: host:<port>/moothies/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Smoothie>> GetSmoothie(int id)
        {
            var smoothie = await _context.Smoothies.FindAsync(id);

            if (smoothie == null)
            {
                return NotFound();
            }

            return smoothie;
        }

        // PUT: host:<port>/smoothies/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutSmoothie(int id, Smoothie smoothie)
        {
            if (id != smoothie.Id)
            {
                return BadRequest();
            }

            _context.Entry(smoothie).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SmoothieExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: host:<port>/smoothies
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Smoothie>> PostSmoothie(Smoothie smoothie)
        {
            _context.Smoothies.Add(smoothie);
            await _context.SaveChangesAsync();

            // return CreatedAtAction("GetSmoothie", new { id = smoothie.Id }, smoothie);
            return CreatedAtAction(nameof(GetSmoothie), new { id = smoothie.Id }, smoothie);
        }

        // DELETE: host:<port>/smoothies/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSmoothie(int id)
        {
            var smoothie = await _context.Smoothies.FindAsync(id);
            if (smoothie == null)
            {
                return NotFound();
            }

            _context.Smoothies.Remove(smoothie);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool SmoothieExists(int id)
        {
            return _context.Smoothies.Any(e => e.Id == id);
        }
    }
}

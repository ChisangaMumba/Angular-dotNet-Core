using Microsoft.EntityFrameworkCore;
using SmoothiesApi.Models;

var builder = WebApplication.CreateBuilder(args);

// Get the connection string from the configuration, or use a default if it's not set.
var connectionString = builder.Configuration.GetConnectionString("Smoothies") ?? "Data Source=Smoothies.db";
//

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();

// Add the database context to the services container.
builder.Services.AddSqlite<SmoothieContext>(connectionString);
//

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.UseSwaggerUi((options) =>
    {
        options.DocumentPath = "/openapi/v1.json";
    });
}

//
app.UseDefaultFiles();
app.UseStaticFiles();
//

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();

//--------------------------------------------------------------------------
import { Component, Input } from '@angular/core';
//--------------------------------------------------------------------------
@Component(
{
  selector: 'app-nav-component',
  templateUrl: './nav-component.component.html',
  styleUrls: ['./nav-component.component.css']
})
//--------------------------------------------------------------------------
class NavComponentComponent 
{
  @Input() title: string = "";
}
//--------------------------------------------------------------------------
export { NavComponentComponent };
//--------------------------------------------------------------------------
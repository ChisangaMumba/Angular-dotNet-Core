//----------------------------------------------------------------------
import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { HomeViewComponent } from "./views/home-view/home-view.component";
import { CreateViewComponent } from "./views/create-view/create-view.component";
import { UpdateViewComponent } from "./views/update-view/update-view.component";
//----------------------------------------------------------------------
const routes: Routes =
[
  { path: '', redirectTo: '/home', pathMatch: 'full' }, // Redirects the root path to '/home'
  { path: "home",  component: HomeViewComponent },
  { path: "create", component: CreateViewComponent },
  { path: ":id", component: UpdateViewComponent },
];
//----------------------------------------------------------------------
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
//----------------------------------------------------------------------
export class AppRoutingModule { }
//----------------------------------------------------------------------

//----------------------------------------------------------
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from "rxjs";
import Smoothie from '../models/smoothie';
const baseUrl = "/smoothies";
//----------------------------------------------------------
@Injectable({providedIn: 'root'})
//----------------------------------------------------------
class SmoothieService
{
  constructor(private http: HttpClient)
  {

  }

  fetchSmoothies(): Observable<Smoothie[]>
  {
    return this.http.get<Smoothie[]>(baseUrl);
  }

  getSmoothieBy_Id(id: string): Observable<Smoothie>
  {
    return this.http.get<Smoothie>(`${baseUrl}/${id}`);
  }

  updateSmoothie(data: Smoothie): Observable<Smoothie>
  {
    return this.http.put<Smoothie>(`${baseUrl}/${data.id}`, data);
  }

  createSmoothie(data: Smoothie): Observable<Smoothie>
  {
    return this.http.post<Smoothie>(baseUrl, data);
  }

  deleteSmoothie(id: string): Observable<any>
  {
    return this.http.delete<Smoothie>(`${baseUrl}/${id}`);
  }
}
//----------------------------------------------------------
export default SmoothieService;
//----------------------------------------------------------

//------------------------------------------------------
class Smoothie
{
    constructor(public id: number= 0, public title: string="", public method: string="", public rating: number=0)
    {

    }
}
//------------------------------------------------------
export default Smoothie;
//------------------------------------------------------

//-------------------------------------------------------------
import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SwalComponent } from "@sweetalert2/ngx-sweetalert2/public-api";
import Smoothie from 'src/app/models/smoothie';
import SmoothieService from 'src/app/services/smoothie.service';
//-------------------------------------------------------------
@Component({
  selector: 'app-update-view',
  templateUrl: './update-view.component.html',
  styleUrls: ['./update-view.component.css']
})
//-------------------------------------------------------------
class UpdateViewComponent implements OnInit
{
  public smoothie: Smoothie = new Smoothie(); 

  @ViewChild("successSwal")
  public readonly successSwal!: SwalComponent;

  @ViewChild("failureSwal")
  public readonly failureSwal!: SwalComponent;

  constructor(private smoothieService: SmoothieService, private route: ActivatedRoute, private router: Router)
  {
    
  }

  ngOnInit(): void 
  {
    this.getSmoothie(this.route.snapshot.params["id"]);
  }

  getSmoothie(id: string): void
  {
    this.smoothieService.getSmoothieBy_Id(id)
    .subscribe(
    {
      next: (data: Smoothie)=>
      {
        this.smoothie = {...data};
      }
    });
  }

  update(): void 
  {
    this.smoothieService.updateSmoothie(this.smoothie)
    .subscribe(
    {
      next: ()=>
      {
        this.router.navigate(["/home"]);
        this.successSwal.fire();
      },

      error: ()=>
      {
        this.failureSwal.fire();
      }
    });
  }
}
//-------------------------------------------------------------
export { UpdateViewComponent };
//-------------------------------------------------------------
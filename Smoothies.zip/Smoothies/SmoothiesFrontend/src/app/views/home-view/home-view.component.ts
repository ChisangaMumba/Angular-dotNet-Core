//---------------------------------------------------------------------------
import { Component, Injectable, OnInit, ViewChild } from "@angular/core"
import { SwalComponent } from "@sweetalert2/ngx-sweetalert2/public-api";
;import Smoothie from "src/app/models/smoothie";
import SmoothieService from "src/app/services/smoothie.service";
//---------------------------------------------------------------------------
@Component({
  selector: "app-home-view",
  templateUrl: "./home-view.component.html",
  styleUrls: ["./home-view.component.css"]
})
//---------------------------------------------------------------------------
@Injectable()
class HomeViewComponent implements OnInit
{
  public smoothies: Smoothie[];

  public labels: string[] = ["time created", "title", "rating"];

  public currentBtn = -1;

  @ViewChild("successSwal")
  public readonly successSwal!: SwalComponent;

  @ViewChild("failureSwal")
  public readonly failureSwal!: SwalComponent;

  constructor(private smoothieService: SmoothieService)
  {

  }

  ngOnInit()
  {
    this.get();
  }

  get(): void
  {
    this.smoothieService.fetchSmoothies()
    .subscribe(
    {
      next: (data: Smoothie[])=>
      {
        this.smoothies = [...data];
      },

      error: ()=>
      {
        this.failureSwal.fire();
      }
    });
  }

  delete(id: string): void 
  {
    this.smoothieService.deleteSmoothie(id)
    .subscribe(
    {
      next: ()=>
      {
        this.successSwal.fire();
        this.get();
      },

      error: ()=>
      {
        this.failureSwal.fire();
      }
    });
  }

  setCardOrder(label: string)
  {
    let orderedItems: Smoothie[] = this.smoothies.sort((a: Smoothie, b: Smoothie)=>
    {
      return (a[label] > b[label]) ? 1 : -1;
    });

    this.smoothies = [...orderedItems];
  }

  setActiveBtn(i: number): void
  {
    this.currentBtn = i;
    this.setCardOrder(this.labels[i]);
  }
}
//---------------------------------------------------------------------------
export { HomeViewComponent };
//---------------------------------------------------------------------------
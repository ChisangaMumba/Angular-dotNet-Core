//-----------------------------------------------------------
import { Component, ViewChild } from "@angular/core";
import { SwalComponent } from "@sweetalert2/ngx-sweetalert2/public-api";
import Smoothie from "src/app/models/smoothie";
import SmoothieService from "src/app/services/smoothie.service";
//-----------------------------------------------------------
@Component({
  selector: "app-create-view",
  templateUrl: "./create-view.component.html",
  styleUrls: ["./create-view.component.css"]
})
//-----------------------------------------------------------
class CreateViewComponent
{
  public error: string = "";
  public smoothie: Smoothie = new Smoothie();

  @ViewChild("successSwal")
  public readonly successSwal!: SwalComponent;

  @ViewChild("failureSwal")
  public readonly failureSwal!: SwalComponent;

  constructor(private smoothieService: SmoothieService)
  {

  }

  create(): void
  {
    this.smoothieService.createSmoothie(this.smoothie)
    .subscribe(
    {
      next: ()=>
      {
        this.successSwal.fire();
        this.clearFields();
      },

      error: ({name, statusText})=>
      {
        this.error = `${name}, ${statusText}`;
        this.failureSwal.fire();
      }
    });
  }

  clearFields(): void
  {
    this.smoothie =
    {
      id: 0,
      title: "",
      method: "",
      rating: 0,
    };
  }
}
//-----------------------------------------------------------
export { CreateViewComponent };
//-----------------------------------------------------------

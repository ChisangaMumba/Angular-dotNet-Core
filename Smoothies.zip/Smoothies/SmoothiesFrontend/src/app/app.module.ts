//---------------------------------------------------------------------------------
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from "@angular/common/http";
import { FormsModule } from '@angular/forms';
import { SweetAlert2Module } from '@sweetalert2/ngx-sweetalert2';

import { HomeViewComponent } from './views/home-view/home-view.component';
import { UpdateViewComponent } from './views/update-view/update-view.component';
import { CreateViewComponent } from './views/create-view/create-view.component';
import { NavComponentComponent } from './components/nav-component/nav-component.component';
//---------------------------------------------------------------------------------
@NgModule(
{
  declarations: 
  [
    AppComponent,
    HomeViewComponent,
    UpdateViewComponent,
    CreateViewComponent,
    NavComponentComponent
  ],
  imports: 
  [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    [SweetAlert2Module.forRoot(
    {
      provideSwal: ()=> import("sweetalert2")
      .then(({ default: swal })=> swal.mixin(
      {
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 5000,
        timerProgressBar: true,
        showCloseButton: true,
      }))
    })],
  ],
  providers: [],
  bootstrap: [AppComponent]
})
//---------------------------------------------------------------------------------
export class AppModule { }
//---------------------------------------------------------------------------------